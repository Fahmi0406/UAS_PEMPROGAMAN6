<?php
$kon = mysqli_connect('localhost','root','');
$link = mysqli_select_db($kon,"uas6") or die(mysqli_error());
